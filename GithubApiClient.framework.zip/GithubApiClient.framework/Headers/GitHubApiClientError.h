//
//  GitHubApiClientError.h
//  GithubApiClient
//
//  Created by Mohamed Matloub on 7/3/20.
//  Copyright © 2020 Matloub. All rights reserved.
//

typedef NS_ENUM(NSUInteger, GitHubApiClientError) {
  GitHubApiClientErrorAFNetworkingNotFound,
};
